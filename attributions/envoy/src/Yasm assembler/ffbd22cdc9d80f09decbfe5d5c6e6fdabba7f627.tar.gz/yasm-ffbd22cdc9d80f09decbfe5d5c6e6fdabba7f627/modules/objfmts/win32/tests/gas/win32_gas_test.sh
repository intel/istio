#! /bin/sh
${srcdir}/out_test.sh win32_gas_test modules/objfmts/win32/tests/gas "win32 objfmt" "-f win32 -p gas" ".obj"
exit $?
